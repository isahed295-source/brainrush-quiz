const questions={
bn:[
"কোন প্রাণী ঘুমানোর সময়ও এক চোখ খোলা রাখতে পারে?",
"পৃথিবীর কোন মহাদেশে কোনো স্থায়ী মরুভূমি নেই?",
"কোন ফলের বীজ ফলের বাইরের দিকে দেখা যায়?",
"কোন গ্রহে এক দিন তার এক বছরের চেয়েও দীর্ঘ?"
],
en:[
"Which animal can sleep while keeping one eye open?",
"Which continent has no permanent desert?",
"Which fruit has its seeds visible on the outside?",
"On which planet is one day longer than one year?"
]};
let lang="bn", qi=0, time=10, timerId=null, coins=0;
const $=id=>document.getElementById(id);
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active")}
document.querySelectorAll(".langBtn").forEach(b=>b.onclick=()=>{document.querySelectorAll(".langBtn").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");lang=b.dataset.lang});
$("playBtn").onclick=()=>show("ad");
$("startAfterAd").onclick=()=>{qi=0;show("quiz");loadQ()};
$("nextBtn").onclick=()=>nextQ();
$("homeBtn").onclick=()=>show("home");
function loadQ(){
 clearInterval(timerId); time=10; $("timer").textContent=time;
 $("qCount").textContent=`${qi+1} / 4`;
 $("question").textContent=questions[lang][qi];
 timerId=setInterval(()=>{time--; $("timer").textContent=time;if(time<=0)nextQ()},1000);
}
function nextQ(){
 clearInterval(timerId);
 qi++;
 if(qi>=4){show("endAd");return}
 loadQ();
}
